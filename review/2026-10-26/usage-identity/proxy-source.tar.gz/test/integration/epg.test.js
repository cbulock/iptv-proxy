import { describe, it, beforeEach } from 'mocha';
import { expect } from 'chai';
import { XMLParser } from 'fast-xml-parser';
import { loadFixture, generateXMLTV } from '../helpers.js';
import { deduplicateXmltvRecords } from '../../server/epg.js';

describe('EPG/XMLTV Integration', () => {
  let parser;

  beforeEach(() => {
    parser = new XMLParser({
      ignoreAttributes: false,
      attributeNamePrefix: '@_',
    });
  });

  describe('XMLTV Parsing', () => {
    it('should parse valid XMLTV file', async () => {
      const xmlContent = await loadFixture('valid-epg.xml');
      const parsed = parser.parse(xmlContent);

      expect(parsed).to.have.property('tv');
      expect(parsed.tv).to.have.property('channel');
      expect(parsed.tv).to.have.property('programme');
    });

    it('should extract channel information from XMLTV', async () => {
      const xmlContent = await loadFixture('valid-epg.xml');
      const parsed = parser.parse(xmlContent);

      const channels = [].concat(parsed.tv.channel);

      expect(channels).to.have.length.at.least(2);
      expect(channels[0]).to.have.property('@_id');
      expect(channels[0]).to.have.property('display-name');
    });

    it('should extract programme information from XMLTV', async () => {
      const xmlContent = await loadFixture('valid-epg.xml');
      const parsed = parser.parse(xmlContent);

      const programmes = [].concat(parsed.tv.programme);

      expect(programmes).to.have.length.at.least(2);
      expect(programmes[0]).to.have.property('@_channel');
      expect(programmes[0]).to.have.property('@_start');
      expect(programmes[0]).to.have.property('@_stop');
      expect(programmes[0]).to.have.property('title');
    });

    it('should handle channel icons in XMLTV', async () => {
      const xmlContent = await loadFixture('valid-epg.xml');
      const parsed = parser.parse(xmlContent);

      const channels = [].concat(parsed.tv.channel);
      const channelWithIcon = channels.find(ch => ch.icon);

      expect(channelWithIcon).to.exist;
      expect(channelWithIcon.icon).to.have.property('@_src');
    });
  });

  describe('XMLTV Generation', () => {
    it('should generate valid XMLTV structure', () => {
      const channels = [
        {
          id: 'test.1',
          name: 'Test Channel',
          icon: 'http://example.com/logo.png',
        },
      ];

      const programmes = [
        {
          channel: 'test.1',
          start: '20240101000000 +0000',
          stop: '20240101010000 +0000',
          title: 'Test Show',
          desc: 'A test program',
        },
      ];

      const xml = generateXMLTV(channels, programmes);

      expect(xml).to.include('<?xml version="1.0" encoding="UTF-8"?>');
      expect(xml).to.include('<tv>');
      expect(xml).to.include('</tv>');
      expect(xml).to.include('<channel id="test.1">');
      expect(xml).to.include('<display-name>Test Channel</display-name>');
      expect(xml).to.include('<programme channel="test.1"');
      expect(xml).to.include('<title>Test Show</title>');
    });

    it('should handle channels without icons', () => {
      const channels = [
        {
          id: 'test.1',
          name: 'Test Channel',
        },
      ];

      const xml = generateXMLTV(channels, []);

      expect(xml).to.include('<channel id="test.1">');
      expect(xml).to.include('<display-name>Test Channel</display-name>');
      expect(xml).not.to.include('<icon');
    });

    it('should handle programmes without descriptions', () => {
      const programmes = [
        {
          channel: 'test.1',
          start: '20240101000000 +0000',
          stop: '20240101010000 +0000',
          title: 'Test Show',
        },
      ];

      const xml = generateXMLTV([], programmes);

      expect(xml).to.include('<programme channel="test.1"');
      expect(xml).to.include('<title>Test Show</title>');
      expect(xml).not.to.include('<desc>');
    });

    it('should generate empty XMLTV when no data provided', () => {
      const xml = generateXMLTV([], []);

      expect(xml).to.include('<?xml version="1.0" encoding="UTF-8"?>');
      expect(xml).to.include('<tv>');
      expect(xml).to.include('</tv>');
      expect(xml).not.to.include('<channel');
      expect(xml).not.to.include('<programme');
    });
  });

  describe('XMLTV Validation', () => {
    it('should validate well-formed XMLTV structure', async () => {
      const xmlContent = await loadFixture('valid-epg.xml');

      let isValid = false;
      try {
        const parsed = parser.parse(xmlContent);
        isValid = parsed && parsed.tv && typeof parsed.tv === 'object';
      } catch (err) {
        isValid = false;
      }

      expect(isValid).to.be.true;
    });

    it('should handle potentially malformed XML', () => {
      // Test with XML that might be considered malformed - unclosed channel tag
      // Note: fast-xml-parser is lenient and may successfully parse this
      const invalidXml =
        '<?xml version="1.0"?><tv><channel id="ch1"><display-name>Test</display-name></tv>';

      let parsed;
      let threwError = false;
      try {
        parsed = parser.parse(invalidXml);
      } catch (err) {
        threwError = true;
      }

      // The test passes if either:
      // 1. The parser threw an error (strict parsing)
      // 2. The parser succeeded (lenient parsing)
      // Both are valid behaviors for different parsers
      expect(threwError || parsed).to.exist;
    });

    it('should detect missing required attributes', async () => {
      const xmlContent = await loadFixture('valid-epg.xml');
      const parsed = parser.parse(xmlContent);

      const channels = [].concat(parsed.tv.channel);

      // All channels should have an id attribute
      channels.forEach(channel => {
        expect(channel).to.have.property('@_id');
        expect(channel['@_id']).to.be.a('string');
        expect(channel['@_id']).to.have.length.greaterThan(0);
      });
    });

    it('should validate programme time attributes', async () => {
      const xmlContent = await loadFixture('valid-epg.xml');
      const parsed = parser.parse(xmlContent);

      const programmes = [].concat(parsed.tv.programme);

      // All programmes should have required time attributes
      programmes.forEach(programme => {
        expect(programme).to.have.property('@_channel');
        expect(programme).to.have.property('@_start');
        expect(programme).to.have.property('@_stop');
        expect(programme['@_start']).to.be.a('string');
        expect(programme['@_stop']).to.be.a('string');
      });
    });
  });

  describe('EPG Merging Logic', () => {
    it('deduplicates channel and programme conflicts deterministically while retaining language-tagged titles', () => {
      const englishFirst = {
        '@_channel': 'merged.1',
        '@_start': '20250101000000 +0000',
        '@_stop': '20250101010000 +0000',
        title: [
          { '#text': 'Shared Show', '@_lang': 'en' },
          { '#text': 'Programme partage', '@_lang': 'fr' },
        ],
        desc: 'First source wins',
      };
      const conflictingSecond = {
        '@_channel': 'merged.1',
        '@_start': '20250101000000 +0000',
        '@_stop': '20250101013000 +0000',
        title: 'Shared Show',
        desc: 'Later source must not replace the first record',
      };

      const merged = deduplicateXmltvRecords({
        tv: {
          channel: [
            { '@_id': 'merged.1', 'display-name': 'First Source Name' },
            { '@_id': 'merged.1', 'display-name': 'Later Source Name' },
          ],
          programme: [englishFirst, conflictingSecond],
        },
      });

      expect(merged.tv.channel).to.deep.equal([
        { '@_id': 'merged.1', 'display-name': 'First Source Name' },
      ]);
      expect(merged.tv.programme).to.have.lengthOf(1);
      expect(merged.tv.programme[0]).to.equal(englishFirst);
      expect(merged.tv.programme[0].title).to.deep.equal(englishFirst.title);
    });

    it('should merge multiple EPG sources correctly', () => {
      const epg1 = generateXMLTV(
        [{ id: 'ch1', name: 'Channel 1' }],
        [
          {
            channel: 'ch1',
            start: '20240101000000 +0000',
            stop: '20240101010000 +0000',
            title: 'Show 1',
          },
        ]
      );

      const epg2 = generateXMLTV(
        [{ id: 'ch2', name: 'Channel 2' }],
        [
          {
            channel: 'ch2',
            start: '20240101000000 +0000',
            stop: '20240101010000 +0000',
            title: 'Show 2',
          },
        ]
      );

      const parsed1 = parser.parse(epg1);
      const parsed2 = parser.parse(epg2);

      const merged = {
        tv: {
          channel: [].concat(parsed1.tv.channel || [], parsed2.tv.channel || []),
          programme: [].concat(parsed1.tv.programme || [], parsed2.tv.programme || []),
        },
      };

      expect(merged.tv.channel).to.have.length(2);
      expect(merged.tv.programme).to.have.length(2);
    });

    it('should filter channels by tvg_id', () => {
      const allowedIds = new Set(['ch1', 'ch3']);
      const channels = [
        { '@_id': 'ch1', 'display-name': 'Channel 1' },
        { '@_id': 'ch2', 'display-name': 'Channel 2' },
        { '@_id': 'ch3', 'display-name': 'Channel 3' },
      ];

      const filtered = channels.filter(c => allowedIds.has(c['@_id']));

      expect(filtered).to.have.length(2);
      expect(filtered[0]['@_id']).to.equal('ch1');
      expect(filtered[1]['@_id']).to.equal('ch3');
    });

    it('should filter programmes by channel id', () => {
      const allowedIds = new Set(['ch1', 'ch3']);
      const programmes = [
        { '@_channel': 'ch1', title: 'Show 1' },
        { '@_channel': 'ch2', title: 'Show 2' },
        { '@_channel': 'ch3', title: 'Show 3' },
      ];

      const filtered = programmes.filter(p => allowedIds.has(p['@_channel']));

      expect(filtered).to.have.length(2);
      expect(filtered[0]['@_channel']).to.equal('ch1');
      expect(filtered[1]['@_channel']).to.equal('ch3');
    });
  });
});
